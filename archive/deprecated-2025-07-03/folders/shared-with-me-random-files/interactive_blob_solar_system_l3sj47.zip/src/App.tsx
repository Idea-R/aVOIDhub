import React from 'react';
    import SolarSystem from './components/SolarSystem';

    function App() {
      return (
        <SolarSystem />
      );
    }

    export default App;
